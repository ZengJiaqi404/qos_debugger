#!/usr/bin/env bash
# 对照实验：不同参数下丢包率表现（每次跑 6 秒）
# 直接调用可执行文件，保证能精确 kill 掉节点进程
source /opt/ros/humble/setup.bash
cd "$(dirname "$0")" || exit 1
source install/setup.bash
export ROS_LOG_DIR="$PWD/.roslog" ROS_HOME="$PWD/.roshome"
mkdir -p "$ROS_LOG_DIR" "$ROS_HOME"

PUB="$PWD/install/qos_debugger/lib/qos_debugger/qos_debugger_pub"
SUB="$PWD/install/qos_debugger/lib/qos_debugger/qos_debugger_sub"

cleanup() {
    [ -n "${PPID_:-}" ] && kill -9 "$PPID_" 2>/dev/null
    [ -n "${SPID_:-}" ] && kill -9 "$SPID_" 2>/dev/null
    wait 2>/dev/null
    PPID_=""; SPID_=""
    sleep 1
}

run_case() {
    local label="$1"; shift
    "$PUB" > "$PWD/.exp_pub.log" 2>&1 & PPID_=$!
    sleep 1.5
    "$SUB" > "$PWD/.exp_sub.log" 2>&1 & SPID_=$!
    sleep 1.5
    for cmd in "$@"; do bash -c "$cmd" >/dev/null 2>&1; done
    sleep 6
    printf '%-34s ' "$label"
    grep "累计" "$PWD/.exp_sub.log" | tail -1 | sed 's/.*累计: //'
    cleanup
}

echo "=== 发布端 100 Hz / 订阅回调 30 ms ==="
run_case "A. depth=10,   delay=30ms"
run_case "B. depth=1000, delay=30ms" "ros2 param set /sensor_subscriber depth 1000"
run_case "C. depth=10,   delay=0ms"  "ros2 param set /sensor_subscriber callback_delay_ms 0"
run_case "D. depth=1000, delay=0ms"  "ros2 param set /sensor_subscriber depth 1000" "ros2 param set /sensor_subscriber callback_delay_ms 0"
rm -f "$PWD/.exp_pub.log" "$PWD/.exp_sub.log"
